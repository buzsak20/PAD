A main.py-t kell futtatni.
